package VISTA;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.ComponentOrientation;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.SystemColor;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.UIManager;

public class frmUser {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frmUser window = new frmUser();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public frmUser() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		//ventana
		frame = new JFrame();
		frame.getContentPane().setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 12));
		frame.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
		frame.getContentPane().setBackground(SystemColor.text);
		frame.setBounds(0, 0, 800, 800);
		frame.setLocationRelativeTo(null);
		frame.getContentPane().setLayout(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		//Label informativo
		JLabel JLlogin = new JLabel(" USER 				       		                                     Sungym");
		JLlogin.setBackground(new Color(255, 51, 255));
		JLlogin.setOpaque(true);
		JLlogin.setFont(new Font("Courier New", Font.CENTER_BASELINE, 23));
		JLlogin.setForeground(Color.WHITE);
		JLlogin.setBounds(0, 0, 800, 40);
		frame.getContentPane().add(JLlogin, BorderLayout.NORTH);
		
		//Información usuario
		JLabel JLInfo = new JLabel(" YOUR INFORMATION ");
		JLInfo.setOpaque(true);
		JLInfo.setFont(new Font("Courier New", Font.BOLD | Font.ITALIC, 18));
		JLInfo.setForeground(new Color(255, 51, 255));
		JLInfo.setBounds(0, 40, 800, 40);
		frame.getContentPane().add(JLInfo, BorderLayout.NORTH);
		
		JLabel JLname = new JLabel("Name");
		JLname.setBounds(38, 101, 70, 15);
		frame.getContentPane().add(JLname);
		
		JLabel JLnamec = new JLabel("Sol Marín Esteban");
		JLnamec.setFont(new Font("Dialog", Font.ITALIC, 12));
		JLnamec.setBounds(59, 120, 281, 15);
		frame.getContentPane().add(JLnamec);
		
		JLabel JLDni = new JLabel("DNI");
		JLDni.setBounds(429, 101, 70, 15);
		frame.getContentPane().add(JLDni);
		
		JLabel JLDniC = new JLabel("39500266C");
		JLDniC.setFont(new Font("Dialog", Font.ITALIC, 12));
		JLDniC.setBounds(450, 120, 97, 15);
		frame.getContentPane().add(JLDniC);
		
		JLabel JDBirthdate = new JLabel("Birth date");
		JDBirthdate.setBounds(38, 147, 111, 15);
		frame.getContentPane().add(JDBirthdate);
		
		JLabel JLBirthdateC = new JLabel("25/01/1999");
		JLBirthdateC.setFont(new Font("Dialog", Font.ITALIC, 12));
		JLBirthdateC.setBounds(59, 167, 97, 15);
		frame.getContentPane().add(JLBirthdateC);
		
		JLabel JLAddress = new JLabel("Dirección");
		JLAddress.setBounds(38, 194, 111, 15);
		frame.getContentPane().add(JLAddress);
		
		JLabel JLAddressC = new JLabel("C/ Rafael de casanova 108, 3-2");
		JLAddressC.setFont(new Font("Dialog", Font.ITALIC, 12));
		JLAddressC.setBounds(59, 215, 281, 15);
		frame.getContentPane().add(JLAddressC);
		
	
		

	}
}
