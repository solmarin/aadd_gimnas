package VISTA;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.ComponentOrientation;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.SystemColor;

import javax.swing.JFrame;
import javax.swing.JLabel;

public class frmUser {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frmUser window = new frmUser();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public frmUser() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		//ventana
		frame = new JFrame();
		frame.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
		frame.getContentPane().setBackground(SystemColor.text);
		frame.setBounds(0, 0, 800, 800);
		frame.setLocationRelativeTo(null);
		frame.getContentPane().setLayout(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		//Label informativo
		JLabel JLlogin = new JLabel(" USER 				       		                                     Sungym");
		JLlogin.setBackground(SystemColor.activeCaption);
		JLlogin.setOpaque(true);
		JLlogin.setFont(new Font("Courier New", Font.CENTER_BASELINE, 23));
		JLlogin.setForeground(Color.WHITE);
		JLlogin.setBounds(0, 0, 800, 40);
		frame.getContentPane().add(JLlogin, BorderLayout.NORTH);
		
		//Información usuario
		JLabel JLInfo = new JLabel(" YOUR INFORMATION ");
		JLInfo.setOpaque(true);
		JLInfo.setFont(new Font("Courier New", Font.ITALIC, 18));
		JLInfo.setForeground(SystemColor.activeCaption);
		JLInfo.setBounds(0, 40, 800, 40);
		frame.getContentPane().add(JLInfo, BorderLayout.NORTH);
		
	
		

	}

}
