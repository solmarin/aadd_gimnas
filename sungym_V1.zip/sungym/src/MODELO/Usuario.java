package MODELO;
/**
 * Clase que define los atributos y metodos de un usuario.
 * 
 * @author Sol M. Marín
 * @version 1
 *
 */
public class Usuario {
	//Atributos
	private String DNI;
	private String nombre;
	private String apellidos;
	private String fechaNacimiento;
	private String direccion;
	private String contraseña;
	private String datos;
	private boolean rol;
	private boolean deudor;
	
	//Constructor
	public Usuario(String dNI, String nombre, String apellidos, String fechaNacimiento, String direccion,
			String contraseña, String datos, boolean rol, boolean deudor) {
		super();
		DNI = dNI;
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.fechaNacimiento = fechaNacimiento;
		this.direccion = direccion;
		this.contraseña = contraseña;
		this.datos = datos;
		this.rol = rol;
		this.deudor = deudor;
	}

	//Getters y Setters
	public String getDNI() {
		return DNI;
	}

	public void setDNI(String dNI) {
		DNI = dNI;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellidos() {
		return apellidos;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	public String getFechaNacimiento() {
		return fechaNacimiento;
	}

	public void setFechaNacimiento(String fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public String getContraseña() {
		return contraseña;
	}

	public void setContraseña(String contraseña) {
		this.contraseña = contraseña;
	}

	public String getDatos() {
		return datos;
	}

	public void setDatos(String datos) {
		this.datos = datos;
	}

	public boolean isRol() {
		return rol;
	}

	public void setRol(boolean rol) {
		this.rol = rol;
	}

	public boolean isDeudor() {
		return deudor;
	}

	public void setDeudor(boolean deudor) {
		this.deudor = deudor;
	}
	
	//Metodos
	
	
	

}
