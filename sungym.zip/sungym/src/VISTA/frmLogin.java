package VISTA;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Insets;
import javax.swing.border.Border;
import java.awt.EventQueue;
import java.awt.Font;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import RECURSOS.TextPrompt;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.SystemColor;
import java.awt.Rectangle;
import javax.swing.JPanel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import javax.swing.JTextField;
import javax.swing.JPasswordField;

public class frmLogin {

	private JFrame frame;
	private JTextField JTFUser;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frmLogin window = new frmLogin();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public frmLogin() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		//Ventana
		frame = new JFrame();
		frame.getContentPane().setBackground(SystemColor.text);
		frame.setBounds(100, 100, 450, 300);
		frame.getContentPane().setLayout(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		//Label informativo
		JLabel JLlogin = new JLabel(" LOGIN				       		            Sungym");
		JLlogin.setBackground(SystemColor.activeCaption);
		JLlogin.setOpaque(true);
		JLlogin.setFont(new Font("Courier New", Font.CENTER_BASELINE, 23));
		JLlogin.setForeground(Color.WHITE);
		JLlogin.setBounds(0, 0, 450, 40);
		frame.getContentPane().add(JLlogin, BorderLayout.NORTH);
		
		//TextField usuario
		JTFUser = new JTextField();
		JTFUser.setBounds(144, 83, 150, 24);
		TextPrompt placeholder = new TextPrompt("User", JTFUser);
	    placeholder.changeAlpha(0.75f);
	    placeholder.changeStyle(Font.ITALIC);
		frame.getContentPane().add(JTFUser);
		JTFUser.setHorizontalAlignment(JTextField.LEFT); 
		JTFUser.setColumns(10);
		
		//Contraseña
		passwordField = new JPasswordField();
		passwordField.setBounds(144, 110, 150, 24);
		frame.getContentPane().add(passwordField);
		
		   
		
		//Icono de boton
		ImageIcon iconBSign = new ImageIcon("src/RECURSOS/sign.png");
        ImageIcon iconEBSign = new ImageIcon(iconBSign.getImage().getScaledInstance(30, 30, java.awt.Image.SCALE_DEFAULT));
        
        //Boton para fichar
		JButton bSign = new JButton();
		bSign.setBounds(404, 220, 34, 40);
		frame.getContentPane().add(bSign);
		bSign.setMnemonic(KeyEvent.VK_ENTER);
		bSign.setIgnoreRepaint(true);
		bSign.setBorderPainted(false);
		bSign.setContentAreaFilled(false);
		bSign.setIcon(iconEBSign);
		bSign.setFocusable(false);
		
		
		bSign.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
		
			}
		});
		
				
		
	}
}
